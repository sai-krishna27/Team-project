package com.sample.demo;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BookTest {
	@Autowired
	BookDao dao;

	//adding new book
	@Test
	public void aAddBookTest() {
		Book book=new Book();
		book.setName("java");
		book.setAuthor("book author");
		book.setDescription("book description");
		book.setPrice(500);
		book.setCategory("category");
		boolean isAdded = dao.addBook(book);
		assertTrue(isAdded);
	}
	

	//retrieving all books
	@Test
	public void bGetBookTest() {
		List<Book> books = dao.getAllBooks();
		assertNotNull(books);
	}
	
	
	//update book
	@Test 
	public void cUpdateBookTest() {
		Book book=new Book();
		List<Book> books = dao.getAllBooks();
		book.setId(books.get(0).getId());
		book.setName("java");
		book.setAuthor("book author");
		book.setDescription("book description");
		book.setPrice(500);
		book.setCategory("category");
		book.setEnable("disable");
		boolean isUpdated = dao.updateBook(book);
		assertTrue(isUpdated);
	}
	
	//get all enabled books
		@Test
		public void dGetEnabledBooks() {
			List<Book> book = dao.getEnabledBooks();
			assertNotNull(book);
		}
	
	//retrieving book by name
	@Test
	public void eGetBookByNameTest() { 
		List<Book> book=dao.getBookByName("java");
		assertNotNull(book);
	}
	
	//delete book by id
	@Test
	public void fDeleteBookTest() {
		List<Book> books = dao.getAllBooks();
		boolean isDeleted = dao.deleteBook(books.get(0).getId());
		assertTrue(isDeleted);
	}
	
	//---------failed cases ------------------
	@Test
	public void gDeleteBookTest() {
		boolean isDeleted = dao.deleteBook(10000);
		assertFalse(isDeleted);
	}
	

}
