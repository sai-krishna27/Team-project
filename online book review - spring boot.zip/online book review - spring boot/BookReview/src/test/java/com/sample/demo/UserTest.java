package com.sample.demo;

import static org.junit.Assert.*;

import java.util.Optional;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserTest {

    @Autowired
    private UserDao userDao;
	
    
    //successful addition
	@Test
	public void aAddUserTest() {
		User user=new User();
		user.setEmail("sai@gmail.com");
		user.setName("sai");
		user.setPassword("Sai@123");
		boolean isAdded=userDao.addUser(user);
		assertTrue(isAdded);
	}
	
	
	//failed addition
	@Test
	public void bAddUserTest() {
		User user=new User();
		user.setEmail("sai@gmail.com");
		user.setName("sai");
		user.setPassword("Sai@123");
		boolean isAdded=userDao.addUser(user);
		assertFalse(isAdded);
	}
	
	
	
	@Test
	public void cUpdateUserTest() {
		User user=new User();
		user.setEmail("sai@gmail.com");
		user.setName("sai");
		user.setPassword("Sai@1234");
		boolean isAdded=userDao.updateUser(user);
		assertTrue(isAdded);
	}
	
	//successful search
	@Test
	public void dGetUserByEmailTest() {
		Optional<User> user=userDao.getUser("sai@gmail.com");
		assertNotNull(user);
	}
	
	//failed search
	@Test
	public void eGetUserByEmailTest() {
		Optional<User> user=userDao.getUser("saikrishna@gmail.com");
		assertTrue(user.isEmpty());
	}
	
	//successful login
	@Test
	public void fValidUserLoginTest() {
		boolean isAuthenticated=userDao.validateUser("sai@gmail.com", "Sai@1234");
		assertTrue(isAuthenticated);
	}
	
	//failed login
	@Test
	public void gValidUserLoginTest() {
		boolean isAuthenticated=userDao.validateUser("sai@gmail.com", "Sai@14");
		assertFalse(isAuthenticated);
	}
	
	//successful delete
	@Test
	public void hDeleteUserByEmail() {
		boolean isDeleted=userDao.deleteUser("sai@gmail.com");
		assertTrue(isDeleted);
	}
	
	//failed delete
	@Test
	public void iDeleteUserByEmail() {
		boolean isDeleted=userDao.deleteUser("sai@gmail.com");
		assertFalse(isDeleted);
	}



}
